from ffast.tokeniser import Tokeniser

def load() -> Tokeniser:
    return Tokeniser()