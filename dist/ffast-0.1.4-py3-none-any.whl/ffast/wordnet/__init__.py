from nltk import download
download('stopwords')
download('wordnet')